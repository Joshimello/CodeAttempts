//
//  ViewController.h
//  NTHU-I2P-MiniProject2
//
//  Created by xtutx on 2023/2/1.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end

